# Changelog

## v0.3 — fair patch comparison
- Stops shrinking the entire widescreen screenshot into a 128×128 square.
- Uses a native-resolution center patch up to the model input size; only scales when the source image is too small.
- Adds a non-AI reference image made from the exact same patch and enlarged to the model output dimensions.
- Labels the output explicitly as an AI reconstruction, not a full-frame enhancement.

## v0.2 — dynamic output dimensions
- Reads output tensor dimensions from the loaded TFLite model.
- Allocates the output buffer using the actual runtime tensor shape.
