# Changelog

## v0.2 — dynamic model output dimensions

- Fixed the reported TFLite output-copy exception caused by hard-coded 384 × 384 Java output storage when the runtime model tensor is 512 × 512 × 3.
- Read input/output tensor dimensions from TensorFlow Lite at runtime.
- Allocate the output tensor using actual runtime height, width, and channel dimensions.
- Display actual model input/output dimensions and scale in the app.
- Validate FLOAT32 NHWC RGB tensors before enabling inference.
- Prevent screenshot loading when the model failed to initialize.
