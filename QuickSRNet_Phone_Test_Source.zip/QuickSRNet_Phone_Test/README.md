# Forest Neural Reconstruction — Android proof-of-concept (v0.3)

This is an Android test app for running one still-image crop through QuickSRNetSmall locally on the phone CPU. It does not connect to Colab and does not process the live Godot render loop.

## v0.3: fairer patch comparison

The first test path center-cropped the whole screenshot and resized the entire crop to 128×128. That discarded source detail when the selected screenshot was already much larger than 128×128. The app now extracts a center patch at its native pixel size (up to the model input size) and displays a non-AI reference made from that exact patch enlarged to the same output dimensions. This lets you compare the neural output against ordinary enlargement without changing the source patch.

This still processes only one square patch, not the whole widescreen frame. Whole-frame reconstruction requires tiled inference and blending, which is a separate performance test.

## Fix in v0.2

The previous app assumed that the model output was always `384 × 384`. On the user's phone, TensorFlow Lite reported an output tensor shape of `[1, 512, 512, 3]`, causing this error:

`Cannot copy from a TensorFlowLite tensor (upscaled_image) with shape [1, 512, 512, 3] to a Java object with shape [1, 384, 384, 3].`

The updated app reads both input and output tensor dimensions from the loaded TFLite model at startup. It allocates the output array using the real output dimensions, updates the output label, and shows the actual scale. It does not hard-code 384 × 384.

## Build using one ZIP upload and GitHub Actions

1. Keep this project inside `QuickSRNet_Phone_Test/` in the ZIP.
2. Upload `QuickSRNet_Phone_Test_Source.zip` to the root of your GitHub repository.
3. Create the repository workflow separately at `.github/workflows/build.yml`. The workflow must extract the ZIP, download the model into `app/src/main/assets/QuickSRNetSmall.tflite`, run `gradle --no-daemon assembleDebug`, and upload `app/build/outputs/apk/debug/app-debug.apk` as an artifact.
4. When replacing the ZIP with a new version, commit the updated ZIP using the same filename. The repository workflow should run automatically on that ZIP path.
5. Open **Actions** → latest build run → **Artifacts** → `Forest-Neural-Test-APK`. Download and extract the artifact ZIP, then install `app-debug.apk`.

The archive includes a workflow for the case where the extracted project files themselves are committed at the repository root. For the single-ZIP method above, use the outer repository workflow that extracts the uploaded archive first.

## Test protocol

- Select a forest screenshot that has foliage, bark, grass, and fog detail.
- The app extracts one centered patch at native source resolution (or scales up if the source is smaller than the model input).
- Compare the **non-AI reference** and **AI reconstruction**; both show the same patch at the model output dimensions.
- Tap **RUN LOCAL NEURAL MODEL**. The app reports model time only, excluding image loading and display.
- Run at least three times and note the second/third run as well as the first.
- Compare output to input at the same displayed size. Check whether the model adds useful detail or simply over-sharpens edges.

## Limitations

- CPU-only inference. No GPU or NPU delegate is enabled.
- This is a single still-image test, not real-time reconstruction and not a live FPS boost.
- Tensor input/output must be NHWC FLOAT32 RGB. Other tensor types or layouts are rejected with a readable startup message.
- The user-reported output tensor is 512 × 512 for a 128 × 128 input. The app follows the actual tensor dimensions rather than assuming a 3× output.
- A single-patch test is not full-frame upscaling and does not increase game FPS.
- Not compiled or device-tested in this environment. Confirm the GitHub Actions build and test on the target phone.

## Model

QuickSRNetSmall, pinned in the repository workflow to revision `977fb3092a065d512cd587c210cc1341b28b7161`. Model card: https://huggingface.co/qualcomm/QuickSRNetSmall
