package com.andheravan.neuraltest;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.tensorflow.lite.Interpreter;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 44;
    private static final int INPUT_SIZE = 128;
    private static final int OUTPUT_SIZE = 384;
    private Interpreter interpreter;
    private Bitmap selected;
    private Bitmap output;
    private ImageView inputView, outputView;
    private TextView status;
    private Button runButton, saveButton;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        try {
            Interpreter.Options opts = new Interpreter.Options();
            opts.setNumThreads(Math.max(2, Math.min(4, Runtime.getRuntime().availableProcessors())));
            interpreter = new Interpreter(loadModel(), opts);
            int[] in = interpreter.getInputTensor(0).shape();
            int[] out = interpreter.getOutputTensor(0).shape();
            status.setText("Model loaded locally\nInput: " + shape(in) + "  Output: " + shape(out) + "\nChoose a game screenshot.");
            if (in.length != 4 || in[1] != INPUT_SIZE || in[2] != INPUT_SIZE || in[3] != 3 || out.length != 4 || out[1] != OUTPUT_SIZE || out[2] != OUTPUT_SIZE || out[3] != 3) {
                status.append("\nWARNING: model tensor shape differs from expected 128→384 RGB. Inference disabled.");
                runButton.setEnabled(false);
            }
        } catch (Exception e) {
            status.setText("Model load failed: " + e.getMessage() + "\nRebuild using the included GitHub Actions workflow.");
            runButton.setEnabled(false);
        }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24, 28, 24, 32); root.setBackgroundColor(Color.rgb(17,22,20));
        scroll.addView(root);
        TextView title = new TextView(this); title.setText("FOREST NEURAL RECONSTRUCTION"); title.setTextColor(Color.WHITE); title.setTextSize(20); title.setGravity(Gravity.CENTER); root.addView(title);
        status = new TextView(this); status.setTextColor(Color.rgb(190,220,195)); status.setTextSize(14); status.setPadding(0,18,0,18); root.addView(status);
        Button pick = new Button(this); pick.setText("1 · SELECT GAME SCREENSHOT"); root.addView(pick);
        pick.setOnClickListener(v -> { Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i, PICK_IMAGE); });
        TextView inputLabel = label("INPUT CROP · 128 × 128"); root.addView(inputLabel);
        inputView = new ImageView(this); inputView.setAdjustViewBounds(true); inputView.setScaleType(ImageView.ScaleType.FIT_CENTER); inputView.setBackgroundColor(Color.BLACK); root.addView(inputView, new LinearLayout.LayoutParams(-1, 300));
        runButton = new Button(this); runButton.setText("2 · RUN LOCAL NEURAL MODEL"); runButton.setEnabled(false); root.addView(runButton); runButton.setOnClickListener(v -> runInference());
        TextView outputLabel = label("MODEL OUTPUT · 384 × 384"); root.addView(outputLabel);
        outputView = new ImageView(this); outputView.setAdjustViewBounds(true); outputView.setScaleType(ImageView.ScaleType.FIT_CENTER); outputView.setBackgroundColor(Color.BLACK); root.addView(outputView, new LinearLayout.LayoutParams(-1, 340));
        saveButton = new Button(this); saveButton.setText("SAVE RESULT TO PHOTOS"); saveButton.setEnabled(false); root.addView(saveButton); saveButton.setOnClickListener(v -> saveResult());
        TextView note = new TextView(this); note.setTextColor(Color.LTGRAY); note.setTextSize(12); note.setPadding(0,20,0,0); note.setText("Offline test only. The model processes one 128×128 crop, not the live game frame. This measures phone inference time without affecting game FPS. Keep the screenshot free of personal information."); root.addView(note);
        setContentView(scroll);
    }

    private TextView label(String s) { TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(13); t.setPadding(0,18,0,8); return t; }
    private String shape(int[] a) { StringBuilder s = new StringBuilder("["); for(int i=0;i<a.length;i++){if(i>0)s.append(",");s.append(a[i]);} return s.append("]").toString(); }

    private MappedByteBuffer loadModel() throws IOException {
        java.io.File f = new java.io.File(getCacheDir(), "QuickSRNetSmall.tflite");
        if (!f.exists() || f.length() < 1000) {
            try (InputStream asset = getAssets().open("QuickSRNetSmall.tflite"); FileOutputStream out = new FileOutputStream(f)) {
                byte[] buffer = new byte[8192]; int n;
                while ((n = asset.read(buffer)) > 0) out.write(buffer, 0, n);
                out.getFD().sync();
            }
        }
        if (f.length() < 1000) throw new IOException("QuickSRNetSmall.tflite missing or incomplete in app assets");
        try (FileInputStream in = new FileInputStream(f); FileChannel channel = in.getChannel()) { return channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size()); }
    }

    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req == PICK_IMAGE && result == RESULT_OK && data != null) {
            try (InputStream stream = getContentResolver().openInputStream(data.getData())) {
                selected = BitmapFactory.decodeStream(stream);
                if (selected == null) throw new IOException("Could not decode image");
                Bitmap crop = centerCrop(selected, INPUT_SIZE);
                inputView.setImageBitmap(crop); outputView.setImageDrawable(null); output = null;
                runButton.setEnabled(interpreter != null); saveButton.setEnabled(false);
                status.setText("Screenshot loaded. Center crop selected. Tap RUN to test local inference.");
            } catch (Exception e) { status.setText("Image error: " + e.getMessage()); }
        }
    }

    private Bitmap centerCrop(Bitmap src, int size) {
        int side = Math.min(src.getWidth(), src.getHeight());
        int x = (src.getWidth()-side)/2, y = (src.getHeight()-side)/2;
        Bitmap square = Bitmap.createBitmap(src, x, y, side, side);
        return Bitmap.createScaledBitmap(square, size, size, true);
    }

    private void runInference() {
        if (selected == null || interpreter == null) return;
        runButton.setEnabled(false); status.setText("Running on phone CPU…");
        new Thread(() -> {
            try {
                Bitmap input = centerCrop(selected, INPUT_SIZE);
                float[][][][] in = new float[1][INPUT_SIZE][INPUT_SIZE][3];
                int[] px = new int[INPUT_SIZE*INPUT_SIZE]; input.getPixels(px,0,INPUT_SIZE,0,0,INPUT_SIZE,INPUT_SIZE);
                int k=0; for(int y=0;y<INPUT_SIZE;y++) for(int x=0;x<INPUT_SIZE;x++) { int c=px[k++]; in[0][y][x][0]=Color.red(c)/255.0f; in[0][y][x][1]=Color.green(c)/255.0f; in[0][y][x][2]=Color.blue(c)/255.0f; }
                float[][][][] out = new float[1][OUTPUT_SIZE][OUTPUT_SIZE][3];
                long t0=System.nanoTime(); interpreter.run(in,out); long elapsed=System.nanoTime()-t0;
                Bitmap result = Bitmap.createBitmap(OUTPUT_SIZE, OUTPUT_SIZE, Bitmap.Config.ARGB_8888);
                int[] outPx = new int[OUTPUT_SIZE*OUTPUT_SIZE]; k=0;
                for(int y=0;y<OUTPUT_SIZE;y++) for(int x=0;x<OUTPUT_SIZE;x++) {
                    float r=clamp(out[0][y][x][0]), g=clamp(out[0][y][x][1]), b=clamp(out[0][y][x][2]);
                    outPx[k++]=Color.rgb(Math.round(r*255),Math.round(g*255),Math.round(b*255));
                }
                result.setPixels(outPx,0,OUTPUT_SIZE,0,0,OUTPUT_SIZE,OUTPUT_SIZE);
                final double ms=elapsed/1_000_000.0;
                runOnUiThread(() -> { output=result; outputView.setImageBitmap(result); saveButton.setEnabled(true); runButton.setEnabled(true); status.setText(String.format(Locale.US,"LOCAL INFERENCE COMPLETE\nInference: %.2f ms\nInput 128×128 → output 384×384\nCPU threads: %d\nThis is model time only; image loading and display are excluded.",ms,Math.max(2,Math.min(4,Runtime.getRuntime().availableProcessors())))); });
            } catch(Exception e) { runOnUiThread(() -> { status.setText("Inference failed: "+e.getMessage()); runButton.setEnabled(true); }); }
        }).start();
    }
    private float clamp(float x) { return Math.max(0f,Math.min(1f,x)); }

    private void saveResult() {
        if(output==null)return;
        try {
            ContentValues values = new ContentValues(); values.put(MediaStore.Images.Media.DISPLAY_NAME,"QuickSRNet_Forest_Test.png"); values.put(MediaStore.Images.Media.MIME_TYPE,"image/png"); values.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/ForestNeuralTest");
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);
            if(uri==null)throw new IOException("Could not create Photos file");
            try(java.io.OutputStream os=getContentResolver().openOutputStream(uri)){output.compress(Bitmap.CompressFormat.PNG,100,os);}
            Toast.makeText(this,"Saved in Photos / ForestNeuralTest",Toast.LENGTH_LONG).show();
        } catch(Exception e) { status.append("\nSave failed: "+e.getMessage()); }
    }

    @Override protected void onDestroy(){ if(interpreter!=null)interpreter.close(); super.onDestroy(); }
}
