package com.andheravan.neuraltest;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.view.Gravity;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.tensorflow.lite.DataType;
import org.tensorflow.lite.Interpreter;

import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 44;

    private Interpreter interpreter;
    private Bitmap selected;
    private Bitmap selectedCrop;
    private Bitmap output;
    private ImageView inputView;
    private ImageView referenceView;
    private ImageView outputView;
    private TextView status;
    private TextView inputLabel;
    private TextView outputLabel;
    private Button runButton;
    private Button saveButton;

    // Read these from the loaded model instead of assuming a 3x (384x384) output.
    private int inputHeight;
    private int inputWidth;
    private int inputChannels;
    private int outputHeight;
    private int outputWidth;
    private int outputChannels;
    private int cpuThreads;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        try {
            Interpreter.Options opts = new Interpreter.Options();
            cpuThreads = Math.max(2, Math.min(4, Runtime.getRuntime().availableProcessors()));
            opts.setNumThreads(cpuThreads);
            interpreter = new Interpreter(loadModel(), opts);

            int[] inShape = interpreter.getInputTensor(0).shape();
            int[] outShape = interpreter.getOutputTensor(0).shape();
            DataType inType = interpreter.getInputTensor(0).dataType();
            DataType outType = interpreter.getOutputTensor(0).dataType();

            if (inShape.length != 4 || outShape.length != 4
                    || inShape[0] != 1 || outShape[0] != 1
                    || inShape[1] <= 0 || inShape[2] <= 0 || inShape[3] != 3
                    || outShape[1] <= 0 || outShape[2] <= 0 || outShape[3] != 3) {
                throw new IllegalStateException("Unsupported model tensor shapes. Input="
                        + shape(inShape) + ", output=" + shape(outShape));
            }
            if (inType != DataType.FLOAT32 || outType != DataType.FLOAT32) {
                throw new IllegalStateException("This test app currently requires FLOAT32 tensors. Input="
                        + inType + ", output=" + outType);
            }

            inputHeight = inShape[1];
            inputWidth = inShape[2];
            inputChannels = inShape[3];
            outputHeight = outShape[1];
            outputWidth = outShape[2];
            outputChannels = outShape[3];

            inputLabel.setText(String.format(Locale.US, "NATIVE SOURCE PATCH · %d × %d", inputWidth, inputHeight));
            outputLabel.setText(String.format(Locale.US, "AI RECONSTRUCTION · %d × %d", outputWidth, outputHeight));
            status.setText("Model loaded locally\nInput tensor: " + shape(inShape)
                    + "\nOutput tensor: " + shape(outShape)
                    + "\nTensor type: " + inType + "\nChoose a game screenshot.");
        } catch (Exception e) {
            status.setText("Model load failed: " + safeMessage(e)
                    + "\nRebuild using the GitHub Actions workflow and check that the model download succeeded.");
            runButton.setEnabled(false);
        }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 28, 24, 32);
        root.setBackgroundColor(Color.rgb(17, 22, 20));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("FOREST NEURAL RECONSTRUCTION");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        status = new TextView(this);
        status.setTextColor(Color.rgb(190, 220, 195));
        status.setTextSize(14);
        status.setPadding(0, 18, 0, 18);
        root.addView(status);

        Button pick = new Button(this);
        pick.setText("1 · SELECT GAME SCREENSHOT");
        root.addView(pick);
        pick.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, PICK_IMAGE);
        });

        inputLabel = label("INPUT CROP");
        root.addView(inputLabel);
        inputView = new ImageView(this);
        inputView.setAdjustViewBounds(true);
        inputView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        inputView.setBackgroundColor(Color.BLACK);
        root.addView(inputView, new LinearLayout.LayoutParams(-1, 260));

        TextView referenceLabel = label("NON-AI REFERENCE · SAME PATCH UPSCALED TO MODEL SIZE");
        root.addView(referenceLabel);
        referenceView = new ImageView(this);
        referenceView.setAdjustViewBounds(true);
        referenceView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        referenceView.setBackgroundColor(Color.BLACK);
        root.addView(referenceView, new LinearLayout.LayoutParams(-1, 300));

        runButton = new Button(this);
        runButton.setText("2 · RUN LOCAL NEURAL MODEL");
        runButton.setEnabled(false);
        root.addView(runButton);
        runButton.setOnClickListener(v -> runInference());

        outputLabel = label("AI RECONSTRUCTION");
        root.addView(outputLabel);
        outputView = new ImageView(this);
        outputView.setAdjustViewBounds(true);
        outputView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        outputView.setBackgroundColor(Color.BLACK);
        root.addView(outputView, new LinearLayout.LayoutParams(-1, 340));

        saveButton = new Button(this);
        saveButton.setText("SAVE RESULT TO PHOTOS");
        saveButton.setEnabled(false);
        root.addView(saveButton);
        saveButton.setOnClickListener(v -> saveResult());

        TextView note = new TextView(this);
        note.setTextColor(Color.LTGRAY);
        note.setTextSize(12);
        note.setPadding(0, 20, 0, 0);
        note.setText("Offline test only. This version takes one native-resolution square patch from the center of the selected screenshot; it does not shrink the whole screenshot to 128×128. "
                + "The reference shows the same patch enlarged with ordinary bitmap scaling, so you can compare it fairly with the neural result. "
                + "The model output dimensions are read from the model. This is not live game processing or an FPS boost. For a full-screen result, the next step would be multi-tile processing.");
        root.addView(note);
        setContentView(scroll);
    }

    private TextView label(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(13);
        t.setPadding(0, 18, 0, 8);
        return t;
    }

    private String shape(int[] values) {
        StringBuilder s = new StringBuilder("[");
        for (int i = 0; i < values.length; i++) {
            if (i > 0) s.append(", ");
            s.append(values[i]);
        }
        return s.append("]").toString();
    }

    private String safeMessage(Exception e) {
        String message = e.getMessage();
        return message == null || message.trim().isEmpty() ? e.getClass().getSimpleName() : message;
    }

    private MappedByteBuffer loadModel() throws IOException {
        java.io.File f = new java.io.File(getCacheDir(), "QuickSRNetSmall.tflite");
        if (!f.exists() || f.length() < 1000) {
            try (InputStream asset = getAssets().open("QuickSRNetSmall.tflite");
                 FileOutputStream out = new FileOutputStream(f)) {
                byte[] buffer = new byte[8192];
                int n;
                while ((n = asset.read(buffer)) > 0) out.write(buffer, 0, n);
                out.getFD().sync();
            }
        }
        if (f.length() < 1000) throw new IOException("QuickSRNetSmall.tflite is missing or incomplete in app assets");
        try (FileInputStream in = new FileInputStream(f);
             FileChannel channel = in.getChannel()) {
            return channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size());
        }
    }

    @Override
    protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req == PICK_IMAGE && result == RESULT_OK && data != null && data.getData() != null) {
            if (interpreter == null || inputWidth <= 0 || inputHeight <= 0) {
                status.setText("The neural model is not ready. Check model loading and rebuild the APK.");
                runButton.setEnabled(false);
                return;
            }
            try (InputStream stream = getContentResolver().openInputStream(data.getData())) {
                selected = BitmapFactory.decodeStream(stream);
                if (selected == null) throw new IOException("Could not decode the selected image");
                selectedCrop = makeNativeCenterPatch(selected, inputWidth, inputHeight);
                inputView.setImageBitmap(selectedCrop);
                Bitmap reference = Bitmap.createScaledBitmap(selectedCrop, outputWidth, outputHeight, true);
                referenceView.setImageBitmap(reference);
                outputView.setImageDrawable(null);
                output = null;
                saveButton.setEnabled(false);
                runButton.setEnabled(interpreter != null);
                status.setText("Screenshot loaded. Using a " + inputWidth + "×" + inputHeight
                        + " center patch at native source resolution where available. The reference is the same patch enlarged without AI. Tap RUN to compare.");
            } catch (Exception e) {
                status.setText("Image error: " + safeMessage(e));
                runButton.setEnabled(false);
            }
        }
    }

    // Use a native-resolution center patch when the selected screenshot is large enough.
    // Only upscale when the source itself is smaller than the model input.
    private Bitmap makeNativeCenterPatch(Bitmap src, int targetWidth, int targetHeight) {
        float targetAspect = (float) targetWidth / (float) targetHeight;
        int cropWidth = src.getWidth();
        int cropHeight = src.getHeight();
        float sourceAspect = (float) cropWidth / (float) cropHeight;
        if (sourceAspect > targetAspect) {
            cropWidth = Math.round(cropHeight * targetAspect);
        } else {
            cropHeight = Math.round(cropWidth / targetAspect);
        }

        // Limit the crop to the model dimensions when possible, retaining the target aspect ratio.
        float scale = Math.min(1f, Math.min((float) targetWidth / cropWidth, (float) targetHeight / cropHeight));
        cropWidth = Math.max(1, Math.round(cropWidth * scale));
        cropHeight = Math.max(1, Math.round(cropHeight * scale));
        int left = Math.max(0, (src.getWidth() - cropWidth) / 2);
        int top = Math.max(0, (src.getHeight() - cropHeight) / 2);
        Bitmap patch = Bitmap.createBitmap(src, left, top, cropWidth, cropHeight);
        if (patch.getWidth() != targetWidth || patch.getHeight() != targetHeight) {
            Bitmap resized = Bitmap.createScaledBitmap(patch, targetWidth, targetHeight, true);
            if (patch != src && !patch.isRecycled()) patch.recycle();
            return resized;
        }
        return patch;
    }

    private void runInference() {
        if (selectedCrop == null || interpreter == null) return;
        runButton.setEnabled(false);
        saveButton.setEnabled(false);
        status.setText("Running on phone CPU…");
        final Bitmap sourcePatch = selectedCrop;

        new Thread(() -> {
            try {
                Bitmap input = sourcePatch;
                float[][][][] inputTensor = new float[1][inputHeight][inputWidth][inputChannels];
                int[] pixels = new int[inputWidth * inputHeight];
                input.getPixels(pixels, 0, inputWidth, 0, 0, inputWidth, inputHeight);

                int k = 0;
                for (int y = 0; y < inputHeight; y++) {
                    for (int x = 0; x < inputWidth; x++) {
                        int c = pixels[k++];
                        inputTensor[0][y][x][0] = Color.red(c) / 255.0f;
                        inputTensor[0][y][x][1] = Color.green(c) / 255.0f;
                        inputTensor[0][y][x][2] = Color.blue(c) / 255.0f;
                    }
                }

                // Critical fix: allocate output using the actual runtime tensor shape.
                // The user's model reports [1, 512, 512, 3], not [1, 384, 384, 3].
                float[][][][] outputTensor = new float[1][outputHeight][outputWidth][outputChannels];
                long t0 = System.nanoTime();
                interpreter.run(inputTensor, outputTensor);
                long elapsed = System.nanoTime() - t0;

                Bitmap resultBitmap = Bitmap.createBitmap(outputWidth, outputHeight, Bitmap.Config.ARGB_8888);
                int[] outPixels = new int[outputWidth * outputHeight];
                k = 0;
                for (int y = 0; y < outputHeight; y++) {
                    for (int x = 0; x < outputWidth; x++) {
                        float r = clamp(outputTensor[0][y][x][0]);
                        float g = clamp(outputTensor[0][y][x][1]);
                        float b = clamp(outputTensor[0][y][x][2]);
                        outPixels[k++] = Color.rgb(Math.round(r * 255), Math.round(g * 255), Math.round(b * 255));
                    }
                }
                resultBitmap.setPixels(outPixels, 0, outputWidth, 0, 0, outputWidth, outputHeight);

                final double ms = elapsed / 1_000_000.0;
                final double scaleX = (double) outputWidth / inputWidth;
                final double scaleY = (double) outputHeight / inputHeight;
                runOnUiThread(() -> {
                    output = resultBitmap;
                    outputView.setImageBitmap(resultBitmap);
                    outputLabel.setText(String.format(Locale.US, "AI RECONSTRUCTION · %d × %d", outputWidth, outputHeight));
                    saveButton.setEnabled(true);
                    runButton.setEnabled(true);
                    status.setText(String.format(Locale.US,
                            "LOCAL INFERENCE COMPLETE\nInference: %.2f ms\nNative patch %d×%d → AI output %d×%d\nScale: %.2f× horizontal, %.2f× vertical\nCPU threads: %d\nCompare the AI result with the non-AI reference above. Model time only; image loading and display are excluded.",
                            ms, inputWidth, inputHeight, outputWidth, outputHeight, scaleX, scaleY, cpuThreads));
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    status.setText("Inference failed: " + safeMessage(e));
                    runButton.setEnabled(true);
                });
            }
        }, "QuickSRNet-Inference").start();
    }

    private float clamp(float x) {
        if (Float.isNaN(x) || Float.isInfinite(x)) return 0f;
        return Math.max(0f, Math.min(1f, x));
    }

    private void saveResult() {
        if (output == null) return;
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "QuickSRNet_Forest_Test.png");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ForestNeuralTest");
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("Could not create Photos file");
            try (java.io.OutputStream os = getContentResolver().openOutputStream(uri)) {
                if (os == null) throw new IOException("Could not open Photos output stream");
                output.compress(Bitmap.CompressFormat.PNG, 100, os);
            }
            Toast.makeText(this, "Saved in Photos / ForestNeuralTest", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            status.append("\nSave failed: " + safeMessage(e));
        }
    }

    @Override
    protected void onDestroy() {
        if (interpreter != null) interpreter.close();
        super.onDestroy();
    }
}
